﻿using System;

namespace work.bacome.imapclient
{
    public enum eTLSRequirement { indifferent, required, disallowed }
}