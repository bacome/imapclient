﻿using System;

namespace work.bacome.imapclient
{
    public enum eDecodingRequired
    {
        unknown,
        none,
        quotedprintable,
        base64
    }
}